# IntelliX

The make file compiles into intellix.exe. To run any file use the terminal and type './intellix "file_name.ix" to run that file. 
I have created a simple demonstration of what the code can do which is named mainFile.ix. 