#include <iostream>
#include "error_messages.h"

int main()
{
    Warning("This is a warning message.");
    Error("This is an error message.");

    return 0;
}