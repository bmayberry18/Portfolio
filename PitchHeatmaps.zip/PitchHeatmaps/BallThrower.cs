using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Pitcher
{
    public string Name { get; set; }
    public string Team { get; set; }
    public float Height { get; set; }
    public Pitch[] Pitches { get; set; }

    public Pitcher(string name, string team, float height, Pitch[] pitches)
    {
        Name = name;
        Team = team;
        Height = height;
        Pitches = pitches;
    }
}

public class BallThrower : MonoBehaviour
{
    public PitchHeatMap pitchHeatMap;



    public Texture2D FourSeamHeatMapTexture; // Assign this in the inspector
    public Texture2D SliderHeatMapTexture; // Assign this in the inspector
    public Texture2D CurveBallHeatMapTexture; // Assign this in the inspector
    public Texture2D ChangeUpHeatMapTexture; // Assign this in the inspector
    public Texture2D CutterHeatMapTexture; // Assign this in the inspector

    public GameObject ballPrefab;
    public Transform mound;
    public Transform homePlate;
    public GameObject targetPrefab;
    public Vector2 targetPosition;
    public GameObject buttonPrefab;
    public GameObject buttonPanel;
    public Dropdown pitcherDropdown;
    public Color[] colors;

    
    public Pitcher[] pitchers;
    public Pitcher currentPitcher;
    private Dictionary<string, Pitch> pitchDictionary;
    [HideInInspector]
    public GameObject targetObject;
    private Vector3? targetPosition3D;

    private void Start()
    {
        Pitch Curveball = new Pitch(82.9f, 53.9f, -10.1f, CurveBallHeatMapTexture);
        Pitch Changeup = new Pitch(89.1f, 24.4f, 14.2f, ChangeUpHeatMapTexture);
        Pitch Slider = new Pitch(89.1f, 32.6f, -4.7f, SliderHeatMapTexture);
        Pitch Cutter = new Pitch(92.7f, 20.8f, -2.8f, CutterHeatMapTexture);
        Pitch FourSeamFastball = new Pitch(96.7f, 12.0f, 8.4f, FourSeamHeatMapTexture);

        Pitcher pitcher1 = new Pitcher("John Doe", "Team A", 6.2f, new Pitch[] { FourSeamFastball, Curveball, Slider, Changeup, Cutter });
        Pitcher pitcher2 = new Pitcher("Jane Doe", "Team B", 6.0f, new Pitch[] { FourSeamFastball, Curveball, Slider, Changeup });

        pitchers = new Pitcher[] { pitcher1, pitcher2 };
        currentPitcher = pitchers[0];

        pitchDictionary = new Dictionary<string, Pitch>();
        pitchDictionary.Add("FourSeamFastball", FourSeamFastball);
        pitchDictionary.Add("Curveball", Curveball);
        pitchDictionary.Add("Slider", Slider);
        pitchDictionary.Add("Changeup", Changeup);
        pitchDictionary.Add("Cutter", Cutter);

        // Initialize dropdown
        List<Dropdown.OptionData> options = new List<Dropdown.OptionData>();
        foreach (Pitcher pitcher in pitchers)
        {
            options.Add(new Dropdown.OptionData(pitcher.Name + " - " + pitcher.Team));
        }
        pitcherDropdown.ClearOptions();
        pitcherDropdown.AddOptions(options);
        pitcherDropdown.onValueChanged.AddListener(OnPitcherSelected);

        // Initialize buttons
        UpdateButtons();

        // Initialize target object
        targetObject = Instantiate(targetPrefab, new Vector3(targetPosition.x, targetPosition.y, 18.47f), Quaternion.identity);
    }

    private void Update()
    {
        // Check for mouse click
        if (Input.GetMouseButtonDown(0))
        {
            // Raycast from camera to strike zone
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit) && hit.collider.gameObject.CompareTag("StrikeZone"))
            {
                // Set target position
                targetPosition3D = new Vector3(hit.point.x, hit.point.y, 18.47f);
                targetObject.transform.position = targetPosition3D.Value;
                Debug.Log($"Target Position from hit {targetPosition3D}");
            }
        }
    }

    private void UpdateButtons()
    {
        // Clear existing buttons
        foreach (Transform child in buttonPanel.transform)
        {
            Destroy(child.gameObject);
        }

        // Create new buttons
        for (int i = 0; i < currentPitcher.Pitches.Length; i++)
        {
            GameObject buttonObject = Instantiate(buttonPrefab, buttonPanel.transform);
            Button button = buttonObject.GetComponent<Button>();
            Text buttonText = buttonObject.GetComponentInChildren<Text>();

            Pitch pitch = currentPitcher.Pitches[i];
            string pitchName = GetPitchName(pitch);
            buttonText.text = pitchName;

            Color color = colors[i % colors.Length];
            button.onClick.AddListener(() => ThrowBall(pitch, color));
        }
    }

    private string GetPitchName(Pitch pitch)
    {
        foreach (KeyValuePair<string, Pitch> entry in pitchDictionary)
        {
            if (entry.Value == pitch)
            {
                return entry.Key;
            }
        }
        return "Unknown Pitch";
    }

    private void OnPitcherSelected(int index)
    {
        currentPitcher = pitchers[index];
        UpdateButtons();
    }

    private void ThrowBall(Pitch pitch, Color color)
    {
        GameObject ball = Instantiate(ballPrefab, mound.position, Quaternion.identity);
        Baseball ballScript = ball.GetComponent<Baseball>();


        // Get the display plane from the PitchHeatMap script
        Renderer displayPlane = pitchHeatMap.displayPlane;

        // Sample a point from the heatmap
        pitchHeatMap.heatMapTexture = pitch.heatMapTexture;
        pitchHeatMap.displayPlane.material.mainTexture = pitchHeatMap.heatMapTexture;
        pitchHeatMap.SampleHeatMap();

        // Set the target position
        ballScript.initialTargetPosition = targetObject.transform.position;
        ballScript.ThrowBall(pitch, color, targetObject.transform.position);
    }

    private int GetRandomIndex(float[] probabilities)
    {
        float randomValue = Random.value;
        float cumulativeProbability = 0;
        for (int i = 0; i < probabilities.Length; i++)
        {
            cumulativeProbability += probabilities[i];
            if (randomValue < cumulativeProbability)
            {
                return i;
            }
        }
        return probabilities.Length - 1;
    }

    private void OnDrawGizmos()
    {
        // Draw the target position
        Gizmos.color = Color.blue;
        Gizmos.DrawSphere(new Vector3(targetPosition.x, targetPosition.y, 18.47f), 0.1f);
    }
}