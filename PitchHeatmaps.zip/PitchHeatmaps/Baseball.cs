using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Baseball : MonoBehaviour
{
    public float diameter = 0.075f; // 75mm in meters
    public float weight = 0.145f; // 0.145kg
    public Rigidbody rb;

    public Vector3 initialTargetPosition;
    private Vector3 finalTargetPosition;

    private List<Vector3> ballPositions = new List<Vector3>(); // List to store the ball's positions

    public Color debugLineColor;


    private void Start()
    {
        // Set the size of the ball based on the diameter
        transform.localScale = new Vector3(diameter, diameter, diameter);

        // Set the mass of the rigidbody based on the weight
        rb.mass = weight;
    }

    public void ThrowBall(Pitch pitch, Color color, Vector3? finalTargetPosition = null, System.Action callback = null)
    {
        debugLineColor = color;
        if (finalTargetPosition.HasValue)
        {
            initialTargetPosition = new Vector3(finalTargetPosition.Value.x, finalTargetPosition.Value.y, 18.47f) - new Vector3(pitch.horizontalBreak * 0.0254f, -pitch.verticalDrop * 0.0254f, 0);
            this.finalTargetPosition = new Vector3(finalTargetPosition.Value.x, finalTargetPosition.Value.y, 18.47f); 
            // Calculate the new initial target position
        }
        else
        {
            // Calculate the final target position
            this.finalTargetPosition = initialTargetPosition + new Vector3(pitch.horizontalBreak * 0.0254f, -pitch.verticalDrop * 0.0254f, 0);
        }

        // Calculate the direction to the initial target position
        Vector3 direction = (this.initialTargetPosition - transform.position).normalized;

        // Calculate the initial velocity
        float initialVelocity = pitch.velocity * 0.44704f;
        Debug.Log($"Initial Velocity: {initialVelocity}");

        // Set the initial velocity of the ball
        rb.linearVelocity = direction * initialVelocity;

        // Curve the ball to the final target position
        StartCoroutine(CurveBall(this.finalTargetPosition, callback));
    }

    private IEnumerator CurveBall(Vector3 finalTargetPosition, System.Action callback)
    {
        float time = 0;
        Vector3 startPosition = transform.position;
        Vector3 startVelocity = rb.linearVelocity;
        Vector3 veloctiy = startVelocity;

        while (transform.position.z < 18.48f)
        {
            time += Time.deltaTime * 2;
            Vector3 direction = (finalTargetPosition - transform.position).normalized;
            rb.linearVelocity = Vector3.Lerp(startVelocity, direction * startVelocity.magnitude, time);
            veloctiy = rb.linearVelocity;
            // Store the ball's position
            ballPositions.Add(transform.position);
            yield return null;
        }
            rb.linearVelocity = veloctiy;

        if (callback != null)
        {
            callback();
        }
    }


    private void OnDrawGizmos()
    {
        // Draw the initial target position
        Gizmos.color = Color.red;
        Gizmos.DrawSphere(initialTargetPosition, 0.1f);

        // Draw the final target position
        Gizmos.color = Color.green;
        Gizmos.DrawSphere(finalTargetPosition, 0.1f);

        // Draw the ball's positions
        Gizmos.color = debugLineColor;
        Debug.Log(debugLineColor);
        for (int i = 0; i < ballPositions.Count - 1; i++)
        {
            Gizmos.DrawLine(ballPositions[i], ballPositions[i + 1]);
        }
    }


}

public class Pitch
{
    public float velocity;
    public float verticalDrop;
    public float horizontalBreak;
    public Texture2D heatMapTexture; // Added heatmap texture field

    public Pitch(float velocity, float verticalDrop, float horizontalBreak, Texture2D heatMapTexture)
    {
        this.velocity = velocity;
        this.verticalDrop = verticalDrop;
        this.horizontalBreak = horizontalBreak;
        this.heatMapTexture = heatMapTexture;
    }
}