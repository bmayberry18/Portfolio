using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class PitchHeatMap : MonoBehaviour
{
    public Texture2D placeHolder;
    public Texture2D heatMapTexture;

    public Renderer displayPlane; // Assign this in the inspector
    public Renderer grayscaleDisplayPlane; // Assign this in the inspector
    public float sampleRate = 10f; // Adjust this to change how often the script samples the heat map
    public int rows = 25;
    public int cols = 25;
    private Texture2D grayscaleTexture;
    private List<int> validIndices = new List<int>();
    private float[] probabilities;
    public bool drawPixelValidity = false; // Toggle to draw pixel validity
    public bool usePixelValidation = false; // Toggle to use pixel validation instead of box validation

    private void Start()
    {
        if(heatMapTexture == null){
            heatMapTexture = placeHolder;
        }

        // Display the heat map on the plane
        displayPlane.material.mainTexture = heatMapTexture;
        displayPlane.material.mainTextureScale = new Vector2(-1, 1);

        // Create a grayscale texture
        grayscaleTexture = new Texture2D(heatMapTexture.width, heatMapTexture.height);
        for (int x = 0; x < heatMapTexture.width; x++)
        {
            for (int y = 0; y < heatMapTexture.height; y++)
            {
                Color color = heatMapTexture.GetPixel(x, y);
                float grayscale;
                if (color.b > color.r) // If the color is blue
                {
                    grayscale = (color.r + color.g + color.b) / 3f; // Calculate the grayscale value based on the brightness of the color
                    grayscale = 1 - grayscale; // Inverse the grayscale value
                    grayscale = Mathf.Clamp01(grayscale * 0.5f + 0.5f); // Clamp the grayscale value to the range 0.5-1
                }
                else // If the color is red or white
                {
                    grayscale = (color.r + color.g + color.b) / 3f; // Calculate the grayscale value based on the brightness of the color
                    grayscale = Mathf.Clamp01(grayscale * 0.45f); // Clamp the grayscale value to the range 0-0.45
                    if (grayscale > 0.42f) // If the color is white
                    {
                        grayscale = 1f; // Set the grayscale value to 1, so white boxes are displayed as completely white
                    }
                }
                grayscaleTexture.SetPixel(x, y, new Color(grayscale, grayscale, grayscale));
            }
        }
        grayscaleTexture.Apply();
        grayscaleDisplayPlane.material.mainTexture = grayscaleTexture;
        grayscaleDisplayPlane.material.mainTextureScale = new Vector2(-1, 1); // Mirror the grayscale texture

        // Calculate the probability of each box
        probabilities = new float[rows * cols];
        for (int row = 0; row < rows; row++)
        {
            for (int col = 0; col < cols; col++)
            {
                int index = row * cols + col;
                int whitePixels = 0;
                int totalPixels = 0;

                // Check all pixels within the box
                for (int x = (int)((float)col / cols * heatMapTexture.width); x < (int)((float)(col + 1) / cols * heatMapTexture.width); x++)
                {
                    for (int y = (int)((float)row / rows * heatMapTexture.height); y < (int)((float)(row + 1) / rows * heatMapTexture.height); y++)
                    {
                        Color color = heatMapTexture.GetPixel(x, y);
                        bool isWhite = color.r > 0.9f && color.g > 0.9f && color.b > 0.9f;
                        if (isWhite)
                        {
                            whitePixels++;
                        }
                        totalPixels++;
                    }
                }

                // Only consider the box as valid if less than 90% of its pixels are white
                if ((float)whitePixels / totalPixels < 0.05f)
                {
                    float x = (float)col / cols;
                    float y = (float)row / rows;
                    Color color = heatMapTexture.GetPixelBilinear(x, y);
                    float grayscale = (color.r + color.g + color.b) / 3f;
                    grayscale = Mathf.Clamp01(grayscale * 0.45f);
                    probabilities[index] = grayscale;
                    validIndices.Add(index);
                }
                else
                {
                    probabilities[index] = 0f;
                }

                // Debug log for each cell's color and probability
                //Debug.Log($"Cell[{row},{col}] - Probability: {probabilities[index]} - White Pixels: {whitePixels} - Total Pixels: {totalPixels}");
            }
        }

        // Normalize the probabilities
        float sum = 0f;
        foreach (int index in validIndices)
        {
            sum += probabilities[index];
        }

        for (int i = 0; i < probabilities.Length; i++)
        {
            probabilities[i] /= sum;
        }

        // Start sampling the heat map
        //InvokeRepeating("SampleHeatMap", sampleRate, sampleRate);
    }


    public void SampleHeatMap()
    {

        // Measure the time taken to sample a point from the heatmap
        System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
        stopwatch.Start();

        // Select a box based on the probabilities
        float randomValue = Random.value;
        float cumulativeProbability = 0;
        int selectedIndex = -1; // Default to an invalid index
        foreach (int index in validIndices)
        {
            cumulativeProbability += probabilities[index];
            if (randomValue < cumulativeProbability)
            {
                selectedIndex = index;
                break;
            }
        }

        if (selectedIndex == -1)
        {
            Debug.LogError("Failed to select a valid box. Check probabilities and valid indices.");
            return;
        }

        // Calculate the position of the selected box
        int selectedRow = selectedIndex / cols;
        int selectedCol = selectedIndex % cols;
        Bounds bounds = displayPlane.bounds;
        float boxWidth = bounds.size.x / cols;
        float boxHeight = bounds.size.y / rows;
        float _x = bounds.min.x + selectedCol * boxWidth + boxWidth / 2;
        float _y = bounds.max.y - selectedRow * boxHeight - boxHeight / 2;

        // Set the target position
        BallThrower ballThrower = GameObject.FindObjectOfType<BallThrower>();
        if (ballThrower != null)
        {
            ballThrower.targetObject.transform.position = new Vector3(_x, _y, 18.47f);
        }

        stopwatch.Stop();
        Debug.Log("Time taken to sample a point from the heatmap: " + stopwatch.ElapsedMilliseconds + "ms");

        // Debug the probabilities
        for (int row = 0; row < rows; row++)
        {
            float rowProbability = 0f;
            for (int col = 0; col < cols; col++)
            {
                int index = row * cols + col;
                rowProbability += probabilities[index];
            }
            Debug.Log("Row " + row + ": " + rowProbability);
        }

        for (int col = 0; col < cols; col++)
        {
            float colProbability = 0f;
            for (int row = 0; row < rows; row++)
            {
                int index = row * cols + col;
                colProbability += probabilities[index];
            }
            Debug.Log("Column " + col + ": " + colProbability);
        }
    }

    private void OnDrawGizmos()
    {
        if (Application.isPlaying)
        {
            // Get the bounds of the display plane
            Bounds bounds = displayPlane.bounds;

            // Divide the display plane into a 9x9 matrix

            float boxWidth = bounds.size.x / cols;
            float boxHeight = bounds.size.y / rows;

            // Draw gizmos for each box
            if (!usePixelValidation)
            {
                for (int row = 0; row < rows; row++)
                {
                    for (int col = 0; col < cols; col++)
                    {
                        int index = row * cols + col;
                        Color gizmoColor = new Color(0f, 1f, 0f, 1f); // Default to green
                        if (probabilities[index] == 0f)
                        {
                            gizmoColor = new Color(1f, 0f, 0f, 1f); // Set to red if invalid
                        }
                        Gizmos.color = gizmoColor;
                        float x = bounds.max.x - col * boxWidth;
                        float y = bounds.min.y + row * boxHeight;
                        Vector3 topLeft = new Vector3(x, y, bounds.center.z);
                        Vector3 topRight = new Vector3(x - boxWidth, y, bounds.center.z);
                        Vector3 bottomRight = new Vector3(x - boxWidth, y + boxHeight, bounds.center.z);
                        Vector3 bottomLeft = new Vector3(x, y + boxHeight, bounds.center.z);
                        Gizmos.DrawLine(topLeft, topRight);
                        Gizmos.DrawLine(topRight, bottomRight);
                        Gizmos.DrawLine(bottomRight, bottomLeft);
                        Gizmos.DrawLine(bottomLeft, topLeft);
                    }
                }
            }

            // // Draw row and column labels
            // Gizmos.color = Color.white;
            // for (int row = 0; row < rows; row++)
            // {
            //     float y = bounds.min.y + row * boxHeight;
            //     Handles.Label(new Vector3(bounds.min.x - 0.5f, y, bounds.center.z), "Row " + row);
            // }
            // for (int col = 0; col < cols; col++)
            // {
            //     float x = bounds.max.x - col * boxWidth;
            //     Handles.Label(new Vector3(x, bounds.min.y - 0.5f, bounds.center.z), "Col " + col);
            // }

            // Draw pixel validity
            if (drawPixelValidity)
            {
                DrawPixelValidity();
            }
        }
    }

    private void DrawPixelValidity()
    {
        Bounds bounds = displayPlane.bounds;
        for (int x = 0; x < heatMapTexture.width; x++)
        {
            for (int y = 0; y < heatMapTexture.height; y++)
            {
                Color color = heatMapTexture.GetPixel(x, y);
                bool isWhite = color.r > 0.9f && color.g > 0.9f && color.b > 0.9f;
                Gizmos.color = isWhite ? Color.red : Color.green;
                float pixelX = bounds.max.x - (float)x / heatMapTexture.width * bounds.size.x;
                float pixelY = bounds.min.y + (float)y / heatMapTexture.height * bounds.size.y;
                Gizmos.DrawSphere(new Vector3(pixelX, pixelY, bounds.center.z), 0.01f);
            }
        }
    }
}